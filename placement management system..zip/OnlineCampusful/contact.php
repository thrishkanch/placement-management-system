<?php

include('header.php');

	
?>
<div align=center>
<center>

Name :</br>
Mobile : </br>
Email : </br>

</center>
</div>

<?php

include('footer.php');

?>


