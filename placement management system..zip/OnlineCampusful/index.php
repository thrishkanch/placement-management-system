<?php

include('header.php');

	
?>

<center>
<br>
<br>
<img src="32.jpg" alt="NGP college" width="600" height="200">

</center>

<?php

include('footer.php');

?>


