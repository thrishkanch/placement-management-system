<?php

include('Adminheader.php');

?>

<div align=center>
<center><b><f1>Welcome Placement cell</f1></b></center>
</div>
<?php

include('footer.php');

?>


