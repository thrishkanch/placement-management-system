<?php

include('Adminhead.php');

?>

<div align=center>
<center><b><f1>Welcome Admin</f1></b></center>
</div>
<?php

include('footer.php');

?>


